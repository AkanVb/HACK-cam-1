echo -e moveing ...
mkdir /sdcard/jmaxopcam0photos
mv cam* /sdcard/jmaxopcam0photos
echo -e all photos are moved ✔
